package Excepciones;

public class ArriendoException extends Exception{
    public ArriendoException(String msg){
        super(msg);
    }
}