package Vista;

import javax.swing.*;

public class ListadoPagosArriendo {
    private JPanel panel1;
    private JButton button1;
    private JTable table1;

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
