package Modelo;

import java.io.Serializable;

public enum EstadoEquipo implements Serializable{
    OPERATIVO,
    EN_REPARACION,
    DADO_DE_BAJA
}
